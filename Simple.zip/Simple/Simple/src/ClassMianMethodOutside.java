
public class ClassMianMethodOutside {

	public static void main(String args[]){
		
		Student s1=new Student();
		s1.id=20;
		System.out.println("id is"+s1.id);
		System.out.println("name is"+s1.name);
	}
}
