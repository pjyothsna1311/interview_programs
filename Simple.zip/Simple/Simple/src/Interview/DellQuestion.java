package Interview;

public class DellQuestion {
    public static void main(String[] args) {
        AA aa = new BB();
        BB bb = new BB();

        //aa.run();
        bb.run();

    }
}

class AA{

}

class BB extends AA {

    public void run() {
        System.out.println("B method");
    }
}
