package Interview;

public class VoltaileDemo {

    volatile int a = 0;
    volatile int b = 0;
    public static void main(String[] args) {
        VoltaileDemo voltaileDemo = new VoltaileDemo();
        Thread t1 = new Thread(() ->{
            voltaileDemo.increment();
            voltaileDemo.print();
        } );
        Thread t2 = new Thread(() -> {
            voltaileDemo.increment();
             voltaileDemo.print();
        });
        t1.start();
        t2.start();
    }

    public void increment() {
        a++;
        b++;

    }

    public void print(){
        System.out.println("a is " +a +" b is " +b);
    }
}

