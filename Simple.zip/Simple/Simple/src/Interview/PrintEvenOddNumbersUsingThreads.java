package Interview;

public class PrintEvenOddNumbersUsingThreads {
    int counter = 1;
    int max=10;
    public static void main(String[] args) {
        EvenThreadPrinting evenThreadPrinting = new EvenThreadPrinting();
        OddThreadPrinting oddThreadPrinting = new OddThreadPrinting();
        evenThreadPrinting.start();
        oddThreadPrinting.start();
    }

    void printEven() throws InterruptedException {
        synchronized (this){
            while(counter<max){
                while(counter%2 == 1) {
                    wait();
                }
                System.out.println(counter);
                counter++;
                notify();
            }


        }
    }

    void printOdd() throws InterruptedException {
        synchronized (this){
            while(counter < max) {
                while(counter%2 == 0){
                    wait();
                }
                System.out.println(counter);
                counter++;
                notify();
            }

        }
    }

}

class EvenThreadPrinting extends Thread {
    PrintEvenOddNumbersUsingThreads printEvenOddNumbersUsingThreads = new PrintEvenOddNumbersUsingThreads();
    public void run() {
        try {
            printEvenOddNumbersUsingThreads.printEven();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class OddThreadPrinting extends Thread {
    PrintEvenOddNumbersUsingThreads printEvenOddNumbersUsingThreads = new PrintEvenOddNumbersUsingThreads();
    public void run() {
        try {
            printEvenOddNumbersUsingThreads.printOdd();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
