package Interview;

import java.util.LinkedList;
import java.util.Queue;

public class PCDemo {
    int capacity = 2;
    Queue<Integer> queue = new LinkedList<>();
    public static void main(String[] args) {
        PCDemo pcDemo = new PCDemo();
        Thread t1 = new Thread(() -> pcDemo.consume(11));
        Thread t2 = new Thread(() -> pcDemo.produce(6));
        t1.start();
        t2.start();

    }

    public void produce(int n)  {
        synchronized (this){
            for(int i=0 ;i< n; i++) {
                if(queue.size() < capacity) {
                    queue.add(i);
                    System.out.println("produced " + i);
                } else {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                notify();
            }

        }

    }

    public void consume(int n)   {
        synchronized (this){
            for(int i = 0; i<n ; i++) {
                if(queue.size() > 0){
                    queue.remove(i);
                    System.out.println("consumed" + i);
                } else {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                notify();
            }
        }
    }
}
