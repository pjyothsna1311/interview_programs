package Interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Comparator1 {
	
	public static void main(String[] args) {
		ArrayList<Teacher > a=new ArrayList<>();
		Teacher t1=new Teacher("jyo", 25, 10);
		Teacher t2=new Teacher("phani", 20, 20);
		Teacher t3=new Teacher("ravi", 28, 30);
		Teacher t4=new Teacher("ravi", 32, 30);
		a.add(t1);
		a.add(t2);
		a.add(t3);
		a.add(t4);
		System.out.println("before sorting"+a);
		Collections.sort(a, new Teacher());
		System.out.println("after sorting"+a);


		Collections.sort(a, (x,y) -> x.age - y.age);
		System.out.println("sort using lambda on age" + a);
		Collections.sort(a, (x,y) -> y.name.compareTo(x.name));
		System.out.println("sorting using lambda on name" + a);

		//sort based on name -> if names are same then sort based on age
		Collections.sort(a, (x,y) -> {
			int nameCompare = x.name.compareTo(y.name);
			return (nameCompare !=0) ? nameCompare : x.age - y.age;
		});

		System.out.println("after sorting using name and age" + a);

		Collections.sort(a,(x,y) -> {
			if(x.age == y.age){
				return x.name.compareTo(y.name);
			}
			return x.age - y.age;
		});
	}
}

/* Class for single sorting only*/
class Teacher implements Comparator<Teacher>{
	
	String name;
	int age;
	int id;
	public Teacher(String name,int age,int id) {
		// TODO Auto-generated constructor stub
		this.name=name;
		this.age=age;
		this.id=id;
	}

	public Teacher() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compare(Teacher t1, Teacher t2) {
		// TODO Auto-generated method stub
		return t1.name.compareTo(t2.name);
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name+age+id;
	}
	
}
