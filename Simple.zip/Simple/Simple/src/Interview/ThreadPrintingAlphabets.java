package Interview;

public class ThreadPrintingAlphabets {
    public static void main(String[] args) {
        ThreadPrintingAlphabets threadPrintingAlphabets = new ThreadPrintingAlphabets();
        Thread t1 = new Thread(() -> {
            for(int i=0 ;i<2;i++){
               threadPrintingAlphabets.print("A");
            }

        });

        Thread t2 = new Thread(() -> {
            for(int i=0 ;i<2;i++){
                threadPrintingAlphabets.print("B");
            }

        });

        t1.start();
        t2.start();


    }

    public void print(String s){
        synchronized (this) {
            System.out.println(s);
        }
    }
}
