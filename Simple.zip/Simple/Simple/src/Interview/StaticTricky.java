package Interview;

public class StaticTricky {

    public static void main(String[] args) {
        add(10);
        StaticTricky staticTricky = new StaticTricky();
        staticTricky.add(20);
        staticTricky = null;
        staticTricky.add(50); //Even if we make the obj to null calling static methods will not throw NPE
        staticTricky.sub(100); //Calling non static methods on null obj will throw NPE
    }

    static void add(int n) {
        System.out.println(n+10);
    }

    void sub(int n){
        System.out.println(n-10);
    }
}
