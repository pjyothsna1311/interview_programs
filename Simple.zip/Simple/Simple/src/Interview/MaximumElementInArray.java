package Interview;

import java.util.Arrays;
import java.util.Comparator;

public class MaximumElementInArray {
    public static void main(String[] args) {

        int[] a = new int[]{10000, 20, 100, 60};
        int max = a[0];

        for (int i= 1 ;i< a.length;i++) {

            if(a[i] > max) {
                max = a[i];
            }
        }

        System.out.println("max ele is " + max);

        System.out.println("using streams");
        System.out.println(Arrays.stream(a).max());


    }
}
