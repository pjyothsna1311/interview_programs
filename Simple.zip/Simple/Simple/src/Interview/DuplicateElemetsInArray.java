package Interview;

import java.util.HashMap;

public class DuplicateElemetsInArray {

    public static void main(String[] args) {

        int a[] = new int[] {1, 3, 4, 1, 2, 1, 1, 2, 3};

        for(int i = 0; i< a.length; i++ ){
            for (int j = i+1; j< a.length; j++) {
                if (a[i]== a[j] && i!=j) {
                    System.out.println("dup ele is " + a[i]);
                }
            }
        }


        HashMap<Integer, Integer > dup = new HashMap<>();
        for (int i= 0; i< a.length; i++) {
            if(!dup.containsKey(a[i])){
                dup.put(a[i],1);
            } else {
                dup.put(a[i], dup.get(a[i])+1);
            }
        }

        System.out.println(dup);
    }
}
