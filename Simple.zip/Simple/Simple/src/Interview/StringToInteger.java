package Interview;

public class StringToInteger {

	public static void main(String[] args) {
		int i=Integer.parseInt("123");
		System.out.println(i);
		
		
	}
}
