package Interview;

public class StringPattern {

    public static void main(String[] args) {
        //Given sting abcdefg output: agbfced

        String s = "abcdefg";
        StringBuffer sb = new StringBuffer();
        int i = 0, j = s.length() - 1;
        while(i<=j) {
            if(i == j)
                sb.append(s.charAt(i));
            else{
                sb.append(s.charAt(i));
                sb.append(s.charAt(j));
            }
            i++;
            j--;
        }
        System.out.println("output is: " + sb);
    }
}
