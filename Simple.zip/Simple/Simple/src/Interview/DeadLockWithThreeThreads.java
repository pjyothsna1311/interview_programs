package Interview;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DeadLockWithThreeThreads {

    public static void main(String[] args) {
        Resource r1 = new Resource("Thread-1");
        Resource r2 = new Resource("Thread-2");
        Resource r3 = new Resource("Thread-3");
        Lock l1 = new ReentrantLock();
        Lock l2 = new ReentrantLock();
        Lock l3 = new ReentrantLock();


        Thread t1 = new Thread(() -> {
            synchronized (r1) {
                try {
                    System.out.println("Thread 1 locked " + r1.name);
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (r2) {
                    System.out.println("Thread 1 locked " + r2.name);
                }
            }
        });

        Thread t2 = new Thread(() -> {
           synchronized (r2) {
               System.out.println("Thread 2 locked " + r2.name);
               try {
                   Thread.sleep(100);
               } catch (InterruptedException e) {
                   e.printStackTrace();
               }
               synchronized (r3) {
                   System.out.println("Thread 2 locked " + r3.name);
               }
           }
        });

        Thread t3 = new Thread(() -> {
            synchronized (r3) {
                System.out.println("Thread 3 locked "+ r3.name);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (r1) {
                    System.out.println("Thread 3 locked "+ r1.name);
                }
            }
        });
        t1.start();
        t2.start();
        t3.start();



    }


}

class Resource {

    String name;

    Resource(String name) {
        this.name = name;
    }
}
