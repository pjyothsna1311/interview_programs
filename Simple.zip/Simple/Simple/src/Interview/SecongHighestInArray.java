package Interview;

public class SecongHighestInArray {

    public static void main(String[] args) {
        int a[] = {10,5,40,60,1};
        int largest = -1, secondLargest = -1;
        for(int i= 0; i<a.length; i++) {
            if(a[i] > largest) {
                secondLargest = largest;
                largest = a[i];
            }
        }
        System.out.println("largest " + largest + "second largest " + secondLargest);
    }
}
