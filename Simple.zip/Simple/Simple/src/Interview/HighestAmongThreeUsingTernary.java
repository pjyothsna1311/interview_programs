package Interview;

public class HighestAmongThreeUsingTernary {

    public static void main(String[] args) {
        int a = 30, b = 50, c= 100;
        int result = (a>b) ? ((a>c) ? a : c) : ((b>c) ? b :c);
        System.out.println(result);
    }
}
