package Interview;

public class BankDepositUsingSynchronization {

    int balance = 10000;
    public static void main(String[] args) {
        BankDepositUsingSynchronization bankDepositUsingSynchronization = new BankDepositUsingSynchronization();
        Thread t2 = new Thread(() ->bankDepositUsingSynchronization.withDraw(2000));
        Thread t1 = new Thread(() ->bankDepositUsingSynchronization.deposit(2000));
        t2.start();
        t1.start();

        //Here though we have 2 diff threads they will not run in parallel
        //Because when we start t2 it has acquired a lock on BankDeposit.. obj
        //so when t1 is started it will be in waiting state until t2 releases the lock.
    }

    public synchronized void withDraw(int amount){
        if(balance > amount) {
            balance = balance - amount;
            System.out.println("balance withdrawn and remaining balance is" + balance);
        } else {
            System.out.println("no sufficient bal to withdraw");
        }
    }

    public synchronized void deposit(int amount) {
        balance = balance+ amount;
        System.out.println("Amount is added" + balance);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
