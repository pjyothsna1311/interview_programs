package Interview;

public class TatkalBooking {
    int availableTickets = 1;
    public static void main(String[] args) {
       TatkalBooking tatkalBooking = new TatkalBooking();
       Thread t1 = new Thread(() -> {
           try {
               tatkalBooking.bookTickets();
           } catch (InterruptedException e) {
               e.printStackTrace();
           }
       });

        Thread t2 = new Thread(() -> {
            try {
                tatkalBooking.bookTickets();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        t1.start();
        t2.start();

    }

    public void bookTickets() throws InterruptedException {
        synchronized (this) {
            if(availableTickets > 0) {
               // System.out.println("booking ticket for" + Thread.currentThread().getName());
                Thread.sleep(500);
                availableTickets--;
                System.out.println("ticket booked for" + Thread.currentThread().getName());
            }
            else{
                System.out.println("tickets not available for" + Thread.currentThread().getName());
            }
        }
    }
}
