package Interview;

public class PrintMulTableUsingSynchronization {
    public static void main(String[] args) {
        Thread t1 = new Thread(new PrintFiveMul());
        Thread t2 = new Thread(new PrintTenMul());
        t1.start();
        t2.start();

        //Other way
        PrintMulTableUsingSynchronization printMulTableUsingSynchronization = new PrintMulTableUsingSynchronization();
        Thread t3 = new Thread(() -> printMulTableUsingSynchronization.printMul(100));
        Thread t4 = new Thread(() -> printMulTableUsingSynchronization.printMul(200));
        t3.start();
        t4.start();

    }

    synchronized public void printMul(int n){
        for(int i = 1; i<5; i++) {
            System.out.println(n*i);
        }
    }
}

class PrintFiveMul implements Runnable{
    PrintMulTableUsingSynchronization printMulTableUsingSynchronization = new PrintMulTableUsingSynchronization();
    @Override
    public void run() {
        printMulTableUsingSynchronization.printMul(5);
    }
}

class PrintTenMul implements Runnable{
    PrintMulTableUsingSynchronization printMulTableUsingSynchronization = new PrintMulTableUsingSynchronization();
    @Override
    public void run() {
        printMulTableUsingSynchronization.printMul(10);
    }
}


