package Interview;

public class DeadLockUsingMainThread {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("entering into dead lock");
        Thread.currentThread().join();
        System.out.println("this will never execute because main thead will wait for itself to die");


    }
}
