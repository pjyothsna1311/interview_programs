package Interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MutipleMissingNumbers {

    public static void main(String[] args) {
        int a[] = {1, 2, 5, 6};
        int n = 7;
        List<Integer> list = Arrays.stream(a).boxed().collect(Collectors.toList());

        for(int i = 1; i<= n ; i++) {
            if(!list.contains(i)){
                System.out.println("missing number" + i );
            }
        }

    }
}
