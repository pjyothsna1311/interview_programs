package Interview;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Print50NumbersUsingThreads {

    public static void main(String[] args) {

        /*for(int i = 1; i<=50; i++){
            int number = i;
            Thread t1 = new Thread(() -> System.out.println(number + "  " +Thread.currentThread().getName()));
            t1.start();
        }*/

        //Using Executor Service
        ExecutorService executorService = Executors.newFixedThreadPool(50);
        for(int i= 1; i<=50; i++) {
            int number = i;
            executorService.submit(() -> System.out.println(number + "  "+Thread.currentThread().getName()));
        }
        executorService.shutdown();
    }
}
