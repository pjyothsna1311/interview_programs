package Interview;

public class UnderScoresInNumericLiterals {

	public UnderScoresInNumericLiterals() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num=1_00_000;
		System.out.println(num);

	}

}
