package Interview;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Print100NumsUsing100Threads {

    public static void main(String[] args) {
        for(int i = 0; i<100; i++) {
            Thread t = new Thread(new Test100(i));
            t.start();
        }

        System.out.println("doing same with Executor services");
        ExecutorService executorService = Executors.newFixedThreadPool(4);
        for(int i = 0; i<100; i++){
            executorService.execute(new Test100(i));
        }
    }

}

class Test100 implements Runnable{
    int number;
    Test100(int number){
        this.number = number;
    }

    @Override
    public void run() {
        System.out.println(number + Thread.currentThread().getName());
    }
}
