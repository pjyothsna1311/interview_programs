package Interview;

public class MultipleInheritanceWithDefault implements A, B {

    public static void main(String[] args) {
        MultipleInheritanceWithDefault multipleInheritanceWithDefault = new MultipleInheritanceWithDefault();
        multipleInheritanceWithDefault.show();
    }

    @Override
    public void show() {
        //option 1
        System.out.println("my own definition");

        //option 2
        A.super.show();

        //option 3
        A.super.show();
        B.super.show();
    }
}

interface A{

    default void show() {
        System.out.println("inside A interface");
    }
}

interface B {
    default void show() {
        System.out.println("inside interface B");
    }
}
