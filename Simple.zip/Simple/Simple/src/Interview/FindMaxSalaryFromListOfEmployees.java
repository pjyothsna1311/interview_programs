package Interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FindMaxSalaryFromListOfEmployees {

    public static void main(String[] args) {
        List<EmployeeDetails> list = new ArrayList<>();
        list.add(new EmployeeDetails("jyo", 10000));
        list.add(new EmployeeDetails("phani", 2000));
        System.out.println(list.stream().sorted((x, y) -> y.salary - x.salary).collect(Collectors.toList()).stream().findFirst().toString());

    }
}

 class EmployeeDetails {
    String name;

     @Override
     public String toString() {
         return "EmployeeDetails{" +
                 "name='" + name + '\'' +
                 ", salary=" + salary +
                 '}';
     }

     int salary;

    EmployeeDetails(String name, int salary) {
        this.name = name;
        this.salary = salary;
    }


}
