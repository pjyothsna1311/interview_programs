package WiproLearning;

public class ClassHolderDemo {
    boolean b;
    public static void main(String[] args) {

        Class c = ClassHolderDemo.class;
        System.out.println("class loader name is " + c.getClassLoader());//prints app classloader name

        System.out.println("bootstrap classholder name is " + String.class.getClassLoader()); //prints null
        ClassHolderDemo printB = new ClassHolderDemo();
        System.out.println(printB.b);
    }
}
