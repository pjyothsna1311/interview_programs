package WiproLearning;

import learning.Instanceof;

public class ObjectDemo {

    public static void main(String[] args) {
        Jyothsna j = new Jyothsna();
        j.id = 1;
        j.name = "test";
        Jyothsna j1 = new Jyothsna();
        j1.initializeUsingMethod(2,"test2");
        Jyothsna j3 = new Jyothsna(3,"test3");
        System.out.println("initialize using ref variable " + j.id + " " + j.name);
        System.out.println("initialize using const " + j3.id + " " + j3.name);

        Jyothsna createObjUsingNewKeyword = new Jyothsna();

    }
}

class Jyothsna {
    int id;
    String name;

    Jyothsna() {

    }
    Jyothsna(int id, String name) {
        this.id = id;
        this.name = name;
    }
    void initializeUsingMethod (int id, String name) {
        id = id;
        name = name;
        System.out.println("initialize using method name " + id + " " + name);
    }
}
