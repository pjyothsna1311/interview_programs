package WiproLearning;

import Pack.A;
import learning.Instanceof;

public class BnakDepositDemo {


    public static void main(String[] args) {
        Account a = new Account();
        a.insert(1, "jyo", 10000);
        a.display();
        a.withDraw(4000);
        a.withDraw(7000);
    }
}

class Account {
    int accountNum;
    String name;
    int amount;

    void insert (int accountNum, String name, int amount) {
        this.accountNum = accountNum;
        this.name = name;
        this.amount = amount;
    }
    void display() {
        System.out.println("amount is " + amount + "name is " + name);
    }
    void withDraw(int amt) {
        if(amount < amt) {
            System.out.println("Insufficient balance");
        } else {
            amount = amount - amt;
            System.out.println("you can have withdrawn amount now you balance is " + amount);
        }
    }
}
