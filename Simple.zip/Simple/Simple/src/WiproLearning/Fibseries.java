package WiproLearning;

public class Fibseries {

    int fib1 = 0;
    int fib2 = 1;
    int j = 1;
    public static void main(String[] args) {
        Fibseries f = new Fibseries();
        f.fibSeries(5);
        f.fibUsingRecursion(5);
    }

    void fibSeries (int n) {
        int fib1 = 1;
        int fib2 = 2;
        int fib3;
        System.out.println(fib1 + " " + fib2);
        for (int i = 2 ; i <=n ; i++) {
            fib3 = fib1 + fib2;
            System.out.println(fib3);
            fib1 = fib2;
            fib2 = fib3;
        }
    }

    void fibUsingRecursion (int n) {

        while (j < n) {
            int fib3 = fib1 + fib2;
            System.out.println("fib series using recursion " + fib3);
            fib1 = fib2;
            fib2 = fib3;
            j++;
        }

    }
}


/*1 2 3 5 8 13

        n = 6
        fib1 = 1
        fib2 = 2
        fib3 = fib1 + fib2*/
