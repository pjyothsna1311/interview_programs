package WiproLearning;

public class ConstDemo {
    public static void main(String[] args) {
        Parent p = new Child();

        //this is not allowed because constructors are not inherited in child class
       // Child c = new Parent();
        p.print();

    }
}

class Parent {

    void print() {
        System.out.println("inside print of parent class");
    }
}

class Child extends Parent {
    void print() {
        System.out.println("inside print of child class");
    }
}
