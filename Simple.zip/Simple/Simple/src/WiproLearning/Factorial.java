package WiproLearning;

public class Factorial {

    public static void main(String[] args) {
        Factorial f = new Factorial();
        f.fact(6);


    }

    void fact(int n) {
        int fact =1;
        int fact1 =1;
        //one way
        for (int i = 1; i<=n; i++) {
            fact = fact *i;
        }

        System.out.println("factorial is " + fact);

        //second way
        for (int i = n; i>=1 ; i--) {
            fact1 = fact1 * i;
        }
        System.out.println("fact is " + fact1);
    }
}



