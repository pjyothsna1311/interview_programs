
public class ClassWithoutMain {
	
	static{
		
		System.out.println("class without main");
		System.exit(0);
	}
		

}
