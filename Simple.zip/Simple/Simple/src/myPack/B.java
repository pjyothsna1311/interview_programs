package myPack;

public class B {
	
	int a=10;   // By default it gets the access modifier as default. So it is accessible only with
	// the package
	
	protected void display(){
		System.out.println("protected method");
	}

}
