
public class ParameterizedConstructor {
	
	public static void main(String args[]){
		
		Student1 s=new Student1(20,"phani");
		s.display();
		
		
	}

	
	
}
