public abstract class TestAbstractClass {
    public static void main(String[] args) {
        // We should not instantiate abstract class
        //TestAbstractClass testAbstractClass = new TestAbstractClass();
    }
}
