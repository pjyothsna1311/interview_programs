
public class Plant extends Animal {

	Plant() {
		System.out.println("I am plant constructor");
	}
	void name(){
		System.out.println("Iam plant");
	}

}
