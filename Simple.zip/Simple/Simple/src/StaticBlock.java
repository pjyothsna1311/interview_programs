
public class StaticBlock {
	
	
	public static void main(String args[]){
		System.out.println("hi");
	}
	
	//static block will be executed before main method
	static{
		System.out.println("Hello");
	
	}

}
