package Java8;

public class CreateThreadUsingLambda {

    public static void main(String[] args) {

        //With Lambda
        Runnable r1 = () -> {
            System.out.println("Have created the thread");
        };
        Thread t1 = new Thread(r1);
        t1.start();

        //Without Lambda
        Runnable r2 = new Runnable() {
            @Override
            public void run() {
                System.out.println("created thread without lambda");
            }
        };
        Thread t2 = new Thread(r2);
        t2.start();

        new Thread(() -> System.out.println("creating using using lambda and anonumous class")).start();
    }
}
