package Java8;

import java.util.*;
import java.util.stream.Collectors;

public class IntermediateOperationsInStream {

    public static void main(String[] args) {

        List<List<String>> list = Arrays.asList(
                Arrays.asList("Jyothsna", "Jamun"),
                Arrays.asList("Phani", "Jamun"),
                Arrays.asList("Reyu", "Jyo")
        );
        Set<String> intermediateResults = new HashSet<>();

        List<String> result = list.stream()
                .flatMap(List::stream)
                .filter(s -> s.startsWith("J"))
                .map(String::toUpperCase)
                .distinct()
                .sorted()
                .peek(s -> intermediateResults.add(s))
                .collect(Collectors.toList());
        System.out.println("intermediate list results");
        intermediateResults.forEach(System.out::println);
        System.out.println("final result");
        result.forEach(System.out::println);
    }
}
