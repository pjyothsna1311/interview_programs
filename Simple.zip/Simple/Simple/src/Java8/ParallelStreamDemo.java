package Java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ParallelStreamDemo {

    public static void main(String[] args) {
        List<String> list = Arrays.asList("ZHello", "Jyothsna", "Phani", "Ravi");
        list.stream().forEach(System.out::println);
        list.parallelStream().forEach(System.out::println);
        list.parallelStream().forEachOrdered(System.out::println);
        //sorting in natural order
        list.stream().sorted().forEach(System.out::println);
        //sorting in desc order
        Comparator<String> comparator = (String s1, String s2) -> s2.compareTo(s1);
        list.stream().sorted(comparator).forEach(System.out::println);

        list.stream().map(e -> e.concat("hello")).forEach(System.out::println);
    }
}
