package Java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MapVsFlatMap {

    public static void main(String[] args) {
        List<String> fruits = new ArrayList<>();
        fruits.add("apple");
        fruits.add("guava");
        fruits.add("water melon");

        fruits.stream().map(n -> n.length()).collect(Collectors.toList()).forEach(System.out::println);

        List<List<Integer>> list = new ArrayList<>();
        list.add(Arrays.asList(1,2));
        list.add(Arrays.asList(3,4));

        list.stream().flatMap(n -> n.stream()).collect(Collectors.toList()).forEach(System.out::println);
    }
}
