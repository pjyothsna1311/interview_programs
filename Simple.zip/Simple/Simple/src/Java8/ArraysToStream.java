package Java8;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class ArraysToStream {

    public static void main(String[] args) {
        int [] number = {1, 2, 3, 4};
        IntStream intStream = Arrays.stream(number);
        intStream.forEach(System.out::println);

        String[] names = { "jyo", "phani"};
        Stream<String> stringStream = Arrays.stream(names);
        Stream<String> stringStream1 = Stream.of(names);
        stringStream1.forEach(System.out::println);


    }
}
