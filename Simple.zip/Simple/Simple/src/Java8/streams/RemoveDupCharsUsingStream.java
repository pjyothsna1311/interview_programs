package Java8.streams;

import Pack.A;

import java.util.Arrays;
import java.util.stream.Collectors;

public class RemoveDupCharsUsingStream {

    public static void main(String[] args) {
        String s = "programming";
        String result = s.chars().mapToObj(c -> String.valueOf((char) c)).distinct().collect(Collectors.joining());
        System.out.println(result);

        int a[] = {10, 20, 30, 30, 40, 40, 60};
        int ans[] = Arrays.stream(a).distinct().toArray();
        Arrays.stream(ans).forEach(System.out::println);
    }
}
