package Java8.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PrintEvenUsingStreams {

    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(2, 20, 25, 35, 26);
        List<Integer> evenList = list.stream().filter(n -> n%2 ==0).collect(Collectors.toList());
        evenList.forEach(System.out::println);
    }
}
