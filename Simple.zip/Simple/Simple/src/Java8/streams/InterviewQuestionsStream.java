package Java8.streams;

import Pack.A;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class InterviewQuestionsStream {

    public static void main(String[] args) {

        //convert array to stream

       Integer a[] = {1,2,3,4};
       Stream<Integer> streamInt = Arrays.stream(a);
       String s[] = {"jyo", "phani"};
       Stream<String> stringStream = Arrays.stream(s);
       streamInt.forEach(System.out::println);
       stringStream.forEach(System.out::println);
       Stream<String> newStringStream = Stream.of(s);
       newStringStream.forEach(System.out::println);

       //Get a slice of stream -- Get the ele from index 2 to 5
        List<Integer> slice = Arrays.asList(1, 2,3,5, 6, 7);
        slice.stream().skip(2).limit(5).forEach(System.out::println);

        List<List<Integer>> nestedList = new ArrayList<>();
        nestedList.add(Arrays.asList(1, 2, 3));
        nestedList.add(Arrays.asList(5, 6, 7));
        nestedList.stream().flatMap(n -> n.stream()).collect(Collectors.toList())
                .forEach(System.out::println);

        //first ele of stream
        List<Integer> list = Arrays.asList(100, 100, 10);
        System.out.println(list.stream().findFirst());
        System.out.println(list.stream().findAny());

        //find last ele of stream
        System.out.println(list.stream().reduce((first, second) -> second));

        //find dup ele in string using stream
        List<Integer> dupList = Arrays.asList(1,1,3, 4,5, 6,6);
        dupList.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
                .entrySet().stream().filter(n -> n.getValue() >1).map(m -> m.getKey()).forEach(System.out::println);

        //occurence of each char in string
        String phani = "pphhaani";
        phani.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet().stream().forEach(System.out::println);
        //to print dup chars in above string
        phani.chars().mapToObj(c -> (char) c ).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet().stream().filter(n -> n.getValue() > 1).forEach(System.out::println);

        //sort the list
        dupList.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList()).forEach(System.out::println);

        //find longest string in list
        List<String> longestString = Arrays.asList("jyothsna", "phani", "ravi kumar");
        System.out.println(longestString.stream().reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2).get());

        //repeated word in a string
        String repeated = "jyothsna jyothsna is a good girl girl";
        String[] words = repeated.split(" ");
        Arrays.stream(words).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
                .entrySet().stream().filter(n -> n.getValue() > 1).forEach(System.out::println);

        //LinkedHashMap sorting
        LinkedHashMap<Integer, String> linked = new LinkedHashMap<>();
        linked.put(100, "def");
        linked.put(10, "abc");
        linked.entrySet().stream().sorted((o1, o2)-> o1.getKey() - o2.getKey()).forEach(System.out::println);
        linked.entrySet().stream().sorted((o1, o2 )-> o1.getValue().compareTo(o2.getValue())).forEach(System.out::println);

        //make the first letter capital of each word
        String str1 = "jyothsna is good girl";
       String result = Arrays.stream(str1.split(" "))
                .map(word -> word.isEmpty() ? word: Character.toUpperCase(word.charAt(0)) + word.substring(1))
                .collect(Collectors.joining(" "));
        System.out.println(result);

        //Union of two lists
        List<Integer> list1 = Arrays.asList(1, 2, 3, 4, 5, 6);
        List<Integer> list2 = Arrays.asList(4, 5, 6, 7, 8, 9);
        List<Integer> unionList = Stream.concat(list1.stream(), list2.stream())
                .distinct()
                .sorted(Collections.reverseOrder())
                .collect(Collectors.toList());
        System.out.println(unionList);

        //Pairs with target sum
        List<Integer> list3 = Arrays.asList(1, 2, 3, 6, 17, 1, 10, 8);
        List<Integer> list4 = Arrays.asList(1, 17, 12, 12, 2, 4, 6);

        List<String> result1 = list3.stream()
                .flatMap(aa -> list4.stream()
                        .filter(bb -> aa + bb == 18)
                        .map(bb -> aa + "," + bb))
                .collect(Collectors.toList());
        System.out.println(result1);

        //Length of all ele im list
        List<String> lenList = Arrays.asList("jyothsna", "phani");
        List<Integer> len = lenList.stream().map(String::length).collect(Collectors.toList());

        //Length of all ele in nested list
        List<List<String>> nestedList1 = List.of(List.of("jyothsna", "phani"),
                List.of("sunny", "papai"));
        nestedList1.stream().flatMap(n -> n.stream()).map(String::length).collect(Collectors.toList()).forEach(System.out::println);


        //Convert to single list
        List<List<String>> singleList = List.of(List.of("a", "b"),
                List.of("c", "d"));
        singleList.stream().flatMap(n -> n.stream()).collect(Collectors.toList()).forEach(System.out::print);




    }
}
