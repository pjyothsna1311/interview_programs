package Java8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RemoveNullEleFromList {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("abc");
        list.add("def");
        list.add(null);
        System.out.println("before removing list ele");
        list.forEach(n -> System.out.println(n));

        Iterator iterator = list.iterator();
        while (iterator.hasNext()){

            if (iterator.next()== null) {
                iterator.remove();
            }
        }
        System.out.println("after removing null ele");
        list.forEach(n -> System.out.println(n));
    }
}
