package Java8;

import myPack.C;

import java.util.*;

public class SortingWithLambda {

    public static void main(String[] args) {

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("zjyothsna");
        arrayList.add("ravi");
        Collections.sort(arrayList);
        arrayList.forEach(n -> System.out.println(n));
        ArrayList<College> collegeArrayList = new ArrayList<>();
        collegeArrayList.add(new College("jyo", 100));
        collegeArrayList.add(new College("zzza", 2));
        collegeArrayList.add(new College("zzz", 1000));
        collegeArrayList.add(new College("azy", 20));
        Collections.sort(collegeArrayList, (x,y) -> x.id - y.id );
        collegeArrayList.forEach(n -> System.out.println(n.id + "  " + n.name));
        Collections.sort(collegeArrayList, (x,y) -> x.name.compareTo(y.name));
        collegeArrayList.forEach(n -> System.out.println(n.id + "  " + n.name));

        ArrayList<Integer> al = new ArrayList<Integer>();
        al.add(205);
        al.add(102);
        al.add(98);
        al.add(275);
        al.add(203);
        Collections.sort(al, (o1, o2) -> o1 - o2);
        al.forEach(n -> System.out.println(n));

        ArrayList<String> al1 = new ArrayList<String>();
        al1.add("zax");
        al1.add("abc");
        al1.add("");
        Collections.sort(al1, (o1, o2) -> o2.compareTo(o1));
        al1.forEach(n -> System.out.println(n));

        HashMap<Integer, String> hm = new HashMap<>();
        hm.put(100, "abc");
        hm.put(1, "zz");
        Set<Integer> set= hm.keySet();
        ArrayList<Integer> aa = new ArrayList<>(set);
        Collections.sort(aa, (o1, o2) -> o1 - o2);
        aa.forEach(n -> System.out.println(n));

        TreeSet<String> treeSet = new TreeSet<>();
        treeSet.add("phani");
        treeSet.add("amul");
        treeSet.add("jyo");
        System.out.println("tree set ele");
        treeSet.forEach(System.out::println);

        TreeSet<String> reverseOrder = new TreeSet<>((a,b) -> b.compareTo(a));
        reverseOrder.add("phani");
        reverseOrder.add("amul");
        reverseOrder.add("jyo");
        System.out.println("reverseOrder tree set ele");
        reverseOrder.forEach(System.out::println);

        TreeSet<Integer> reverseOrderUsingId = new TreeSet<>((a,b) -> b -a);
        reverseOrderUsingId.add(100);
        reverseOrderUsingId.add(20);
        reverseOrderUsingId.add(1000);
        System.out.println("reverseOrderUsingId tree set ele");
        reverseOrderUsingId.forEach(System.out::println);



    }

}

class College {
    String name;
    int id;

    College(String name, int id ){
        this.name = name;
        this.id = id;
    }

}
