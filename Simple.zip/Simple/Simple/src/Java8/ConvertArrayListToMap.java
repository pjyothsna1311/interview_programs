package Java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ConvertArrayListToMap {

    public static void main(String[] args) {
        List<ListToTest> list = new ArrayList<>();
        list.add(new ListToTest("jyo", 1));
        list.add(new ListToTest("phani", 2));
        list.forEach(System.out::println);

        Map<Integer, String> map = new HashMap<>();
        list.forEach(
                (n) -> { map.put(n.getId(), n.getName()); });

        Map<Integer,String> mapUsingStreams = list.stream().collect(Collectors.toMap(ListToTest::getId, ListToTest::getName));
        mapUsingStreams.forEach((k, v) -> System.out.println(k + " " + v));

        System.out.println(map);

    }
}

class ListToTest{
    String name;
    int id;

    @Override
    public String toString() {
        return "ListToTest{" +
                "name='" + name + '\'' +
                ", id=" + id +
                '}';
    }

    ListToTest(String name, int id){
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
