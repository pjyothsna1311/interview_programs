package Java8;

import myPack.C;

public class CheckStringHasOnlyAlphaUsingLambda {
    public static void main(String[] args) {
        CheckStringHasOnlyAlphaUsingLambda checkStringHasOnlyAlphaUsingLambda = new CheckStringHasOnlyAlphaUsingLambda();

        String s= "GeeksForGeeks";
        System.out.println(checkStringHasOnlyAlphaUsingLambda.checkStringHasAlphabetsUsingRegex(s));
    }

    public boolean checkStringHasAlphabets(String str) {
        return ((str != null) && (!str.equals("") && (str.chars().allMatch(Character::isLetter))));
    }
    public boolean checkStringHasAlphabetsUsingRegex(String str) {
        return ((str != null) && (!str.equals("") && (str.matches("^[a-zA-Z]*$"))));
    }
}
