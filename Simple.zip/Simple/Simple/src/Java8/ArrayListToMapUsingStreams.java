package Java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ArrayListToMapUsingStreams {

    public static void main(String[] args) {
        List<String> fruits = new ArrayList<>();
        fruits.add("banana");
        fruits.add("apple");
        fruits.add("orange");

        HashMap<String, Integer> res = fruits.stream().collect(Collectors.toMap(Function.identity(),
                String::length, (e1,e2) -> e1, HashMap::new));
        System.out.println(res);

        String s = "jyothsnaa";

        Map<Character, Long> countOfEachChar = s.chars().mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println(countOfEachChar);

    }
}
