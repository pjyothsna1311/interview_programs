package Java8;

import Pack.A;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FindEvenNumUsingStream {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        List<Integer> evenNums = new ArrayList<>();

        evenNums = list.stream().filter(n -> n%2 ==0).collect(Collectors.toList());

        /*list.stream().forEach(n -> {
            if (n%2 ==0) {
               evenNums.add(n);
            }
        });*/

        evenNums.forEach(System.out::println);
    }
}
