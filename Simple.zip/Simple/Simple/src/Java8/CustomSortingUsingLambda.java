package Java8;

import java.util.*;
import java.util.stream.Collectors;

//sort students based on age if two students has same age then sort based on their names
public class CustomSortingUsingLambda {

    public static void main(String[] args) {

        List<Students> studentsList = new ArrayList<>();
        studentsList.add(new Students(20,"jyo"));
        studentsList.add(new Students(20,"abc"));
        studentsList.add(new Students(10,"def"));
        studentsList.add(new Students(10,"jyo"));
        System.out.println("before sorting" );
        studentsList.forEach(n -> System.out.println(n.age + "  " + n.name));
        Collections.sort(studentsList, (x,y) -> x.age - y.age == 0 ? x.name.compareTo(y.name) : x.age - y.age);
        System.out.println("after sorting" );
        studentsList.forEach(n -> System.out.println(n.age + "  " + n.name));

        HashMap<Integer,String> map = new HashMap<>();
        map.put(10000,"jyo");
        map.put(100,"zabc");

        //Sort ele of Hashmap based on their values
        List<Map.Entry<Integer,String>> list = map.entrySet().stream().sorted((e1, e2) -> e1.getValue().compareTo(e2.getValue())).collect(Collectors.toList());
        System.out.println("after sorting");

        list.forEach(n -> System.out.println(n.getKey() + "   " + n.getValue()));

        try {
            System.out.println("Hello" + " " + 1/0);
        } catch (Exception e) {
            System.out.println("catch");
        } finally {
            System.out.println("finally");
        }

        String s=new String("Hello");
        StringBuffer sb= new StringBuffer(s);
        sb.deleteCharAt(0);
        System.out.println(sb);

        int[] a = new int[0];
        System.out.print(a.length);

        Thread t = Thread.currentThread();
        System.out.println(t.isAlive());

    }
}

class Students {
    int age;
    String name;

    Students(int age, String name)  {
        this.age = age;
        this.name = name;
    }


}
