package Java8;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Stream;

public class Assessment {

    public static void main(String[] args) {


    }
}


 interface StringFormatter1 {
    String format(String s1, String s2);
}




