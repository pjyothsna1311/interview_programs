package Java8;

import java.util.Map;
import java.util.Optional;

public class OptionalDemo {

    public static void main(String[] args) {
        String[] words= new String[10];
        //String word = words[5].toUpperCase();

        //This throws NPE
        //System.out.println(word);

        Optional<String> checkIfNull = Optional.ofNullable(words[5]);
        if(checkIfNull.isPresent()) {
            System.out.println(words[5].length());
        } else {
            System.out.println("word is not present");
        }

        //Demo for of method

        String[] str = new String[10];
        str[2] = "Hai Jyo";
        Optional<String> empty = Optional.empty();
        Optional<String> value = Optional.of(str[2]);
        System.out.println(empty + "    " + value);

        //ofNullable Method -- returns an instance of optional with value, if value is null returns empty optional
        Optional<Integer> op = Optional.ofNullable(123);
        System.out.println("int value is " + op + "  " + op.get() );
        Optional<String> num = Optional.ofNullable(null);
        System.out.println(num);

        //orElse returns the value is present else returns the alternate value that is specified
        Optional<Integer> num1 = Optional.of(100);
        System.out.println(num1.orElse(200));
        Optional<Integer> num2 = Optional.empty();
        System.out.println(num2.orElse(200));


        //ifPresentOrElse demo
        num1.ifPresentOrElse((value1) -> {System.out.println(value1);}, () -> System.out.println("empty") );
        num2.ifPresentOrElse((value2) -> System.out.println(value2), () -> System.out.println("empty"));

        //orElseGet Method
        System.out.println(num1.orElseGet(() -> (int) Math.random() * 10));
        System.out.println(num2.orElseGet(() -> (int)Math.random() * 20));
    }
}
