package Java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class TerminalOperationsStream {

    public static void main(String[] args) {
        List<String> names = Arrays.asList("Jyothsna", "Phani", "Ravi", "Jayu", "Reyu");
        names.forEach(System.out::println);
        List<String> jNames = names.stream().filter(n -> n.startsWith("J")).collect(Collectors.toList());
        jNames.forEach(System.out::println);
        long count= names.stream().count();
        System.out.println(count);
        String concatenatedName = names.stream().reduce("",(partialString, element) -> partialString+" "+element);
        System.out.println(concatenatedName);
        names.stream().findFirst();
    }
}
