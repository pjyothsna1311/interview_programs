package Java8;

import Pack.A;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.function.*;

public class TypesOfFunctionalInterfaces {

    public static void main(String[] args) {
        Consumer<List<Integer>> modify = list -> {
            for(int i = 0; i< list.size(); i++)
                list.set(i, 2*list.get(i));
        };

        //Takes one arg and returns no result
        Consumer<List<Integer>> display = list -> list.stream().forEach(System.out::println);

        BiConsumer<List<Integer>, List<Integer>> equal = (list1, list2) -> {
            if(list1.size() == list2.size())
                System.out.println("true");
        };
        BiConsumer<List<Integer>, List<Integer>> displayBiList = (list1, list2) -> {
            System.out.println(list1);
        };
        List<Integer> list = Arrays.asList(1, 2,3);
        List<Integer> anotherList = Arrays.asList(1, 2,3);

        modify.andThen(display).accept(list);
        //modify.andThen(null).accept(list); --> throws NPE
        equal.andThen(displayBiList).accept(list, anotherList);

        Predicate<String> stringContains = s -> s.contains("p");
        String s = "jyothsna";
        System.out.println(stringContains.test(s));

        Predicate<Integer> greaterThan10 = n -> n > 10;
        Predicate<Integer> lessThan20 = n -> n < 20;
        System.out.println(lessThan20.and(greaterThan10).test(1500));

        User user1 = new User("jyo", 1);
        User user2 = new User("jyo", 1);
        TypesOfFunctionalInterfaces typesOfFunctionalInterfaces = new TypesOfFunctionalInterfaces();
        List<User> users = new ArrayList<>();
        users.add(user1);
        users.add(user2);
        typesOfFunctionalInterfaces.process(users, (User u ) -> u.getName().equals("jyo"));

        Function<Integer, Integer> half = a -> a/2;
        Function<Integer,Integer> multiplyBy3 = a -> a*3;
        System.out.println(half.andThen(multiplyBy3).apply(10));
        System.out.println(half.compose(multiplyBy3).apply(20));

        Supplier<Double> random = () -> Math.random();
        System.out.println(random.get());






    }

    public List<User> process(List<User> users, Predicate<User> predicate) {
        List<User> addedList = new ArrayList<>();
        users.forEach(n -> {
            if(predicate.test(n))
                addedList.add(n);
        });
        System.out.println(addedList);
    return addedList;
    }
}

class User{
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    int role;

    User(String name, int role) {
        this.name = name;
        this.role = role;
    }

}