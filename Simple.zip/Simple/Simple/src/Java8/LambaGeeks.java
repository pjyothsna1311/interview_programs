package Java8;

import java.util.ArrayList;

public class LambaGeeks {
    public static void main(String[] args) {
        //Without Lamba
        Geeks g = new Geeks() {
            @Override
            public void add(int x) {
                System.out.println(x+20);
            }
        };

        //With Lambda
        g.add(10);
        Geeks g1 = (x) -> System.out.println( x+ 50);
        g1.add(20);

        Geeks1 geeks1 = (x,y) -> System.out.println(x *y);
        geeks1.mul(2,3);

        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(4);
        arrayList.add(5);

        arrayList.forEach(n -> {
            if (n%2 == 0) {
                System.out.println(n);
            }
        });
    }




}

interface Geeks {
    void add (int x);
    //If we add one more method to interface we can't use Lambda exp. Because Lambda exp will work with only Funtional
    //Interface which has only one method in it.
    // void mul(int x, int y);
}

interface Geeks1 {
    void mul(int x, int y);
}

