package Java8;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class PredicateExample {

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("Geeks");
        list.add("beeks");
        list.add("yeeks");
        list.add("ggeeks");

        Predicate<String> p = s -> s.startsWith("G");

        for(String s: list) {
            if (p.test(s)) {
                System.out.println("yes matching the predicate " + s);
            }
        }
    }
}
