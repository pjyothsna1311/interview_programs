
public class Rectangle {
	int length;
	String name;
	

	//Initialization through method
	
	void namingRectangle(int l,String n){
		length=l;
		name=n;
		//System.out.println(length+""+name);
		
	}
	
	void namingRectangle1(int l,String n){
		length=l;
		name=n;
		//System.out.println(length+""+name);
		
	}

	
	void display(){
		System.out.println(length+""+name);
	}
	
	void display1(){
		System.out.println(length+""+name);
	}
	
	//Intialization through constructor
	
	
	
	
}
