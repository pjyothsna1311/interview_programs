package com.ds;

public class LinkedListDemo {

	public LinkedListDemo() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class Node{
	int data;
	Node next;
	
	Node(int data){
		this.data=data;
	}
	
	public void add(int data){
		Node n=new Node(data);
		
	}
}