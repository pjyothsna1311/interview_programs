
public class ClassMainMethodInside {
	int id;
	String name;
	public static void main(String args[]){
		
		ClassMainMethodInside c=new ClassMainMethodInside();
		c.name="Jyo";
		System.out.println("id is"+c.id);
		System.out.println("name is"+c.name);
		
		
	}

}
