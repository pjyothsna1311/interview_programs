package learning;

public class MainMethodPrivate {

    private static void main(String args[]) {
        System.out.println("abc");
    }
}
