package learning;

public class TestRavi {

    public static void main(String args[]) {
        TestRavi testRavi = new TestRavi();
        System.out.println(testRavi.add());

    }

    public int add() {
        int x = 0;
        return x++;
    }
}
