package learning;

public class TypeCasting {

    public static void main(String args[]){
        int a= 10;
        float f = a;
        System.out.println(f);

        float f1= 10;
        int b= (int)f1;
        System.out.println(b);

    }
}
