package learning;

public class CommandLineArgs {

    public static void main(String args[]) {
        System.out.println("enter args");
        for(String i: args){
            System.out.println(i);

        }
    }
}
