package learning;

public class WrapperClass {

    public static void main(String args[]) {
        int a= 20;
        Integer i = a;
        System.out.println(i);

        Integer j =30;
        int k =j;
        System.out.println(k);
    }
}
