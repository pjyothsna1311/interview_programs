package learning;

public class EnumExample {

    enum color{
        RED,BLUE,GREEN;
    }
    public static void main(String args[]) {
        color c1 = color.BLUE;
        System.out.println(c1);
    }


}
