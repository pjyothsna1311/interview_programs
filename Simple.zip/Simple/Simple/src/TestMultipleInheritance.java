
public class TestMultipleInheritance extends Plant{
	
	public static void main(String args[]){
		
		TestMultipleInheritance t=new TestMultipleInheritance();
		t.name();
		System.out.print(t.name);
	}

}
