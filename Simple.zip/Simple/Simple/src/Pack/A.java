package Pack;
import myPack.*;
public class A {
	
	public static void mian(String args[]){
		
		B b=new B();
		/*System.out.println(b.a);  Will through compilation error because variable a is of default
		type and it is not accessible outside the package. */
		
		
	}
	

}
