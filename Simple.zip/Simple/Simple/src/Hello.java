
class Hello {
public static void main(String []args){

	System.out.println("hello");
	int i=10;
	System.out.println(i);
	String s="Jyothsna";
	System.out.println(s+i);
	System.out.println(i+i);
	String p= s.concat("Papai");
	System.out.println(p+s);
	
}
}
