
public class Animal {

	String name="dog";
}
